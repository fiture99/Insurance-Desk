import React from "react";
import ReactDOM from "react-dom/client";
import { InsuranceDesk } from "./InsuranceDesk";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <InsuranceDesk />
  </React.StrictMode>
);
