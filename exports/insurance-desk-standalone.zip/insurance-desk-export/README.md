# AfricMed Insurance Desk

A tool for hospital insurance staff to track and action member requests (add/remove dependents, reinstate, update details).

This is a front-end mockup — all data lives in memory in the browser (no backend, no database). Refreshing the page resets it back to the sample data.

## Run locally

Requires [Node.js](https://nodejs.org) 18 or later installed.

```bash
npm install
npm run dev
```

Then open the URL shown in the terminal (usually `http://localhost:5173`).

## Sign-in credentials (sample data)

- Admin: `admin` / `admin123`
- Staff: `fatou` / `desk2025`
